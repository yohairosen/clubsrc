<a href="#" class="trigger gmap" data-trigger-class="gmap-triggered" data-trigger-on="#main" data-trigger-off="#main"></a>

