<a href="#" class="trigger search" data-trigger-class="search-triggered" data-trigger-on="header .azqf-query-form" data-trigger-off="header .azqf-query-form"></a>

